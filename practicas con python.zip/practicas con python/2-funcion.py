def informacion():
    print("soy david")

informacion()    