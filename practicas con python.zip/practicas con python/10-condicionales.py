# revisar si una condicon es mayor mayor a
balance= 500
if balance>0:
    print("puedes pagar")
else:
    print("no tienes saldo")    

#likes
#para asinar un valos uso = para comparar si un valor es igual a otro uso ==
likes=200    
if likes >=200:
    print("exclente, 200 likes")

else:
    print("casi llegas a los 200")    

#if con texto
lenguaje="php" 

if not lenguaje == "python":
    print("excelente decision")

#evaluar boleano
usuario_autenticado = True

if usuario_autenticado:
    print("acceso al sistema")
else:
    print("debes iniciar sesion")    