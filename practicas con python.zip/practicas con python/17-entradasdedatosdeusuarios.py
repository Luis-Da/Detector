# input detiene la ejecuacion del codigo hasta que el usuario realice la entrada de un dato
nombre= input("cual es tu nombre: \r\n ") #\r\n crea un salto de linea
print(f"hola {nombre}")

#leer datos que seran numeros
edad= input("cual es tu edad")
#convertir edad en string
#las entradas de datos vienen como string, si se van a entrar numeros hay que convertilos
edad=int(edad)
if edad >= 18:
    print("ya puedes votar:  \r\n")
else:
    print("aun no puedes votar:  \r\n")    

#mezclarlos con operadores    

numero=input("agregar un numero para verificar que sea par")
numero=int(numero)
if numero % 2 ==0:
    print(f"el numero {numero} es par")
else:
      print(f"el numero {numero} no es par")
        
