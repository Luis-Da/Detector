def informacion(nombre):
    return nombre
empleado= informacion("juan")
print(empleado)