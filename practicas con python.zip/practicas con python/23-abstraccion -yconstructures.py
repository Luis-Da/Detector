class Restaurante:
    def __init__(self,nombre,categoria,precio):#constructor
        self.nombre=nombre #atributo
        self.categoria=categoria#atributo
        self.precio=precio#atributo
    
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self.precio}")

#instanciar la clase       
# nombre de variable se escoje arbitrariamente
restaurante=Restaurante("pizzeria mexico","comida italiana ", 50) #restaurante seria un objeto y Resturante seria una clase
restaurante.mostrar_informacion() #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros

#cuando creo un nuevo objeto mando a llamar la clase y creo un funcion para agregar

restaurante2=Restaurante("hamburguesa python","comida casual", 20) #restaurante seria un objeto y Resturante seria una clase
restaurante2.mostrar_informacion() #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros
  
#un constructor es una funcion que se crea automaticamente al crear un nuevo objeto por medio de una clase

#pilares de la programacion orientada a objetos
#- abstraccion: son los datos necesarrios de una clase, si elabiras un menu de restaurante es necesario el nombre del platillo, descripcion y precio
#otros datos como el color favorito del chef no son necesarios
