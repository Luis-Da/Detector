usurario_logueado= True
usuario_admin= True
if usurario_logueado and usuario_admin:
    print("administrador")

elif    usurario_logueado: # intermedios consecutivos e ilimitados
    print("acceso al sistema")

else: #else final defimitivo
    print("debes iniciar sesion")    



usurario_logueado1= True
usuario_admin1= False
if usurario_logueado1 or usuario_admin1:
    print("administrador")

elif    usurario_logueado1: # intermedios consecutivos e ilimitados
    print("acceso al sistema")

else: #else final defimitivo
    print("debes iniciar sesion")    