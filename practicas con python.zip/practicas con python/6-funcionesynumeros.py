def suma(a,b=0): #funcion suma
    print(a+b)

suma(2,3)    
suma(5,3) 
suma(2,70) 

def resta(a,b=0): #funcion resta
    print(a-b)

resta(2,3)    
resta(5,3) 
resta(2,70) 

def producto(a,b=0): #funcion multicplicacion
    print(a*b)

producto(2,3)    
producto(5,3) 
producto(2,70) 




def division(a,b=0): #funcion division
    print(a/b)

division(2,3)    
division(5,3) 
division(2,70) 