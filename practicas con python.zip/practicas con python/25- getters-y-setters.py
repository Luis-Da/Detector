#una vez  que se hacen PRIVATE las variables de las clases ya no se pueden modificar asignando un nuevo valor a la variable
#se debe de modificar por medio de un metodo, que se conocen como getters y setters
#get obtiene un valor y set agrega o modifica un valor

class Restaurante:
    def __init__(self,nombre,categoria,precio):#constructor
        self.nombre=nombre #atributo
        self.categoria=categoria#atributo
        self.__precio=precio#atributo   -por defecto estos atribus son publicos entonces se pueden modificar en cualquier lado Default:public
        #PROTECTED para evitar que se modifiquen los atributos (self._nombreatributo= nombreatributo) y eso es encapsulamiento
        #PRIVATE se logra con doble guion bajo (self.__nombreatributo= nombreatributo) contrl+d para selecionar todos los valores iguales y modificarlo
        #al hacerlo PRIVATE solo se puede acceder a el por medio de un metodo, esos metodos son getters y setters
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self.__precio}")

    def get_precio(self):
        print(self.__precio)

    def set_precio(self, precio) :
        self.__precio= precio


#instanciar la clase       
# nombre de variable se escoje arbitrariamente
restaurante=Restaurante("pizzeria mexico","comida italiana ", 50) #restaurante seria un objeto y Resturante seria una clase

#restaurante.__precio=80# no sera posible midificarlo  con private __
restaurante.mostrar_informacion() #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros

#cuando creo un nuevo objeto mando a llamar la clase y creo un funcion para agregar

restaurante2=Restaurante("hamburguesa python","comida casual", 20) #restaurante seria un objeto y Resturante seria una clase
restaurante.set_precio(100)
restaurante.get_precio()


restaurante2.mostrar_informacion() #llamo la funcion en forma de un meto
restaurante2.set_precio(10)
restaurante2.get_precio()

 
