numero =0
while numero <=10:
    print(numero)
    numero+=1 #incremento para evitar un loop infinito

    #if dento del while

    while numero <=10:
        if numero == 5:
           # break #rompe ejecucion del codigo
            print("CINCOOO!!!")
            numero+=1
        else:
            print(numero) 
            numero+=1   