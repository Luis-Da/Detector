# el polimorfismo es la habilidqd de tener diferentes comprtamientos basado en que 
#subclase se esta utilizando, relacionado muy estrechamente con herancia
class Restaurante:
    def __init__(self,nombre,categoria,precio):
        self.nombre=nombre 
        self.categoria=categoria
        self._precio=precio  
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self._precio}")

    def get_precio(self):
        print(self._precio)

    def set_precio(self, precio) :
        self._precio= precio




restaurante=Restaurante("pizzeria mexico","comida italiana ", 50)
restaurante.mostrar_informacion() 

restaurante2=Restaurante("hamburguesa python","comida casual", 20) 
restaurante.set_precio(100)
restaurante.get_precio()


restaurante2.mostrar_informacion() 
restaurante2.set_precio(10)
restaurante2.get_precio()

#crear una clase hijo de restaurante -heredar

class Hotel(Restaurante):
    def __init__(self, nombre, categoria, precio, alberca):
        super().__init__(nombre, categoria, precio)#constructor del padre
        self.alberca=alberca
#para reexcribir un metodo debe llamarse igual
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self.s_precio}, alberca: {self.alberca}")
    
        #agregar un metodo que solo exista en hotel
    def get_alberca(self)    :
        return self.alberca

hotel=Hotel("Hotel poo", "5 estrellas", 200, "si")

hotel.mostrar_informacion()
alberca= hotel.get_alberca()
print(alberca)