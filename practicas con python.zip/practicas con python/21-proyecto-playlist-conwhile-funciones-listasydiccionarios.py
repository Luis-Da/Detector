#pregunta a usuario sobre nombrar un playlist y agragar canciones
#cuando se cra un applicacion mas real lo ideal es tener una funcion principal
playlist={} #dicccionario vacio
playlist["canciones"]=[] # lista vacia de canciones o vector vacio de canciones

#funciion principal
def app():
   agregar_playlist=True
   while agregar_playlist:
       nombre_playlist= input("como deseas nombrar la playlist?:\r\n")

       if nombre_playlist:
        playlist["nombre"]=nombre_playlist #agregando al diccionario la llave nombre y el introducido en el input nombre_playlist
       #dado aque ingresaron nombre se desactiva el true
        agregar_playlist=False
        
        #mandara llamar la funcion para agregar canciones
        agregar_canciones()
# se conoce como bandera cuando existe una variable true que hace un cambio de valor a false o viceversa


def agregar_canciones():
   #bandera para agrgar canciones
   agregar_cancion = True
   while agregar_cancion:
      #preguntar al usuario que cancion desea agregar
      nombre_playlist=playlist["nombre"]
      pregunta= f"agrega canciones para la playlist {nombre_playlist}: \r\n"
      pregunta+= "escribe 'x' para dejar de agregar canciones: \r\n"

      cancion= input(pregunta)

      if cancion=='x':
         print("finalizando..")
         agregar_cancion = False
         #dejar de agregar canciones
         mostrar_resumen()
        #mostrar resumen de la playlist
      else:
           #agregar canciones a la playlist  
       playlist["canciones"].append(cancion)
       print(playlist)
    
def mostrar_resumen():
   nombre_playlist= playlist["nombre"]
   print(f"playlist:  {nombre_playlist } \r\n ")
   print("canciones: \r\n")    
   for cancion in playlist["canciones"]:
      print("cancion")
     


app()