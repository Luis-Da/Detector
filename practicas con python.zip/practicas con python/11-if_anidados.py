lenguajes=["python","kotlin", "java", "javascript"]
if "php" in lenguajes:
    print("php si existe")
else:
    print("no, no esta en la lista")

#if anidados
usuario_autenticado = True
usuario_admin = True

if usuario_autenticado:
    if usuario_admin:
        print("Acceso total")
else:
       print("debes inicar seccion")     