lenguajes=["python","kotlin", "java", "javascript"]
for lenguaje in lenguajes :
    if lenguaje == "python":
        print(lenguaje.upper())
    else:
        print(lenguaje)    