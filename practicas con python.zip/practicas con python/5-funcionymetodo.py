# funcion-> mostrarnombre(nombre):nombre de la funcion y le pasamos la variable -- metodo->nombre.upper() : variable un punto y nombre de la funcion
#jemplo funcion
nombre="pedro"
def mostrar_nombre(nombre):
    print(f"hola {nombre}")

mostrar_nombre(nombre)

#ejemplo metodo

print(nombre.upper())


# retos
#1  una funcion que improma un mesanje de bienvenida

def mensaje():
    print("bienvenido")

mensaje()  

#2 tome nombre de usuario y da bienvenida
print("ingrese un usuario")
usuario=input()

def mensaje(usuario):
    print(f"bienvenido {usuario}")

mensaje(usuario)  

