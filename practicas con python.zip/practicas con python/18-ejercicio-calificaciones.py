respuestas=["si","no","si"]
nota=0
puntos=5/3

print("este examen consta de 3 pregunta, responda si o no dado el caso")
pregunta1=input("el amarrillo es un color primario: \r\n")
if pregunta1==respuestas[0]:
    nota=nota+puntos
else:
    nota=nota    
pregunta2=input("las vacas ponen huevos: \r\n")
if pregunta2==respuestas[1]:
    nota=nota+puntos
else:
    nota=nota    

pregunta3=input("hay mas agua salada que agua dulce: \r\n")
if pregunta3==respuestas[2]:
    nota=nota+puntos
else:
    nota=nota    

print(f"su nota en este examen es de: {nota}")
