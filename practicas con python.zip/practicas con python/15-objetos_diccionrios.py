#un objeto es similar a un array o lista permite agrupar contenido  de distintos tipos de datos en una sola variable
#en un objetos se accede por medio de una llave que se conoce como un (key)
#en python los objetos se conocen como diccionario

#creando un diccionarrio simple

cancion={
    "artista": "metallica", #llave y valor se separa por comas
    "cancion": "enter sadman",
    "lanzamiento": 1992,
    "likes": 3000
}
#entonces la variable cancion tiene distinto valores entre enteros y string
print(cancion["artista"])#se accede al valor metallica por medio de la llave cancion
print(cancion["lanzamiento"])
#mesclar con un string

print(f"estoy escuchando a {cancion['artista']}")

#puedo asignar un elemnto a una  variable
artista=cancion["artista"]
print(f"estoy escuchando a {artista}")

#agrdgar nuevos valores
cancion["playlist"]="heavy metal"
print(cancion)

#reemplazar valor existente

cancion["cancion"]="seek y destroy"
print(cancion["cancion"])

#eliminar un valor

del cancion["lanzamiento"]
print(cancion) 
