def app():
    with open("archivo.txt")  as archivo: #modo r es modo lectura, por defecto asi se abren los archivos
        for contenido in archivo:
            print(contenido.rstrip()) #.rstrip para quitar salto de lina





app()    