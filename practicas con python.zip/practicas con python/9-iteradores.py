lenguajes=["python","kotlin", "java", "javascript"]
print(lenguajes)
print(lenguajes[0])
print(lenguajes[1])
print(lenguajes[2])
print(lenguajes[3])

#iterador
for lenguaje in lenguajes:
    print(f"estoy aprendiendo {lenguaje}")

#for que escriba numeros
for numero in range(0,10):
    print(numero)    