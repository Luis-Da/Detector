lenguajes=["python","kotlin", "java", "javascript"]
print(lenguajes)

#existen metodos propios para las listas ejemplo
#ordenar los elementos
lenguajes.sort()
print(lenguajes)

#acceder a un elemento dentro de un texto

aprendiendo=f"estoy aprendiendo {lenguajes[3]}"
print(aprendiendo)

#modificando valores de un arreglo
lenguajes[2]="php"
print(lenguajes)


#agregar elemt+entos a un arreglo
lenguajes.append("ruby")
print(lenguajes)

#eliminar de un arreglo o lista
del lenguajes[1]
print(lenguajes)

#eliminar ultimo elemento

lenguajes.pop()
print(lenguajes)

#eliinar una pocision especifica con .pop

lenguajes.pop(1)
print(lenguajes)

#eliminar por nombres
lenguajes.remove("java")
print(lenguajes)