#-encapsulamiento: permite restringir u ocultar el acceso a los datos dentro dela misma clase del mundo exterior
# ( usualmente se modifician via metodos en la misma clase)

class Restaurante:
    def __init__(self,nombre,categoria,precio):#constructor
        self.nombre=nombre #atributo
        self.categoria=categoria#atributo
        self.__precio=precio#atributo   -por defecto estos atribus son publicos entonces se pueden modificar en cualquier lado Default:public
        #PROTECTED para evitar que se modifiquen los atributos (self._nombreatributo= nombreatributo) y eso es encapsulamiento
        #PRIVATE se logra con doble guion bajo (self.__nombreatributo= nombreatributo) contrl+d para selecionar todos los valores iguales y modificarlo
        #al hacerlo PRIVATE solo se puede acceder a el por medio de un metodo, esos metodos son getters y setters
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self._precio}")

#instanciar la clase       
# nombre de variable se escoje arbitrariamente
restaurante=Restaurante("pizzeria mexico","comida italiana ", 50) #restaurante seria un objeto y Resturante seria una clase

restaurante.__precio=80# no sera posible midificarlo  con private __
restaurante.mostrar_informacion() #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros

#cuando creo un nuevo objeto mando a llamar la clase y creo un funcion para agregar

restaurante2=Restaurante("hamburguesa python","comida casual", 20) #restaurante seria un objeto y Resturante seria una clase

restaurante2._precio=40
restaurante2.mostrar_informacion() #llamo la funcion en forma de un meto