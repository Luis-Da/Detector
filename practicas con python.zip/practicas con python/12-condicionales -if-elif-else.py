ocupacion="estudiante"

if ocupacion == "estudiante":
    print("tienes 50% de descuento")
elif ocupacion == "jubilado":
    print("tienes descuento del 75%")
elif ocupacion== ("desempleado") :
    print(" tienes descuento del 10%")   
else:
    print("debes pagar el 100%")        