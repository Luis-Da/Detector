# class cliente:
#resto de la clase

#cliente=cliente() ->instancia

#la programacio  orientada a objetos (POO) es una forma de escrbir codigo efectiva y se considera que es un estandar
#defines lo que se conoce como una clase y describes su comportamiento y forma
#objeto es la forma de referirse a la informacion creada por una clase (instancia de una clase)
#cada instancia de la clase tendra la misma forma pero diferente informacion

#instacia es objeto creado al llamar una clase
#atributo de clase, es una propiedad que tendra todos los objetos creados con nuestras clases es como se le da forma alos datos
#metodo es una funcion que existe dentro de una clase
class Restaurante:
    def agregar_restaurante(self,nombre): # argumento self
        self.nombre=nombre#atributo
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}")

#instanciar la clase       
# nombre de variable se escoje arbitrariamente
restaurante=Restaurante() #restaurante seria un objeto y Resturante seria una clase
restaurante.agregar_restaurante("pizzeria mexico") #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros
restaurante.mostrar_informacion()


restaurante2=Restaurante() #restaurante seria un objeto y Resturante seria una clase
restaurante2.agregar_restaurante("hamburguesa python") #llamo la funcion en forma de un metodo, el self se pasa automaticaticamente no se ve pero lo debo inlucir como parametro por que es lo que necesito para guardarla infotmacion de los demas parametros
restaurante2.mostrar_informacion()

#una funcion dentro de una clase se conoce como metodo

# otra forma de mostrar informacion
print(f"Nombre restaurante: {restaurante.nombre}")
print(f"Nombre restaurante: {restaurante2.nombre}")
