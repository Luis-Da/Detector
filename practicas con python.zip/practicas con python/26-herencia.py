#herencia : puedes una clase que sea hijo o una copia de otra, al heredar una clase tendras todos sus metodos y 
#atributos de las clase padre en el hijo, y podras modificarlosrn cvaso de ser necesario

#
class Restaurante:
    def __init__(self,nombre,categoria,precio):
        self.nombre=nombre 
        self.categoria=categoria
        self.__precio=precio  
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}, categoria: {self.categoria}, precio: {self.__precio}")

    def get_precio(self):
        print(self.__precio)

    def set_precio(self, precio) :
        self.__precio= precio




restaurante=Restaurante("pizzeria mexico","comida italiana ", 50)
restaurante.mostrar_informacion() 

restaurante2=Restaurante("hamburguesa python","comida casual", 20) 
restaurante.set_precio(100)
restaurante.get_precio()


restaurante2.mostrar_informacion() 
restaurante2.set_precio(10)
restaurante2.get_precio()

#crear una clase hijo de restaurante -heredar

class Hotel(Restaurante):
    def __init__(self, nombre, categoria, precio):
        super().__init__(nombre, categoria, precio)

hotel=Hotel("Hotel poo", "5 estrellas", 200)

hotel.mostrar_informacion()