#iniciar un diccionario vacio
jugador={}
print(jugador)
# se une un  jugador
jugador["nombre"]="juan"
jugador["puntaje"]= 0
print(jugador) #cuando inicializo el diccionario doy valor a las llaves con (:), cuando voy agregando por que inicialice la variable vacia asigno valor a las llaves con(=)

jugador["puntaje"]=200
print(jugador)

#acceder a un valor

print(jugador["puntaje"])




#iterar en el diccionario
for llave,valor in jugador.items():

    print(valor)


#eliminar jugador y puntaje

del jugador["puntaje"]
del jugador["nombre"]

print(jugador)