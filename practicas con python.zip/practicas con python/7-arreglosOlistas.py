#lista, arreglo o vector
meses=["enero", "febrero", "marzo"]

# inicia la cuenta desde posicionon 0 ejemplo, meses[0]= enero, meses[1]= febrero, meses[2]= marzo