def informacion(nombre, puesto= "desconocido"):
    print(f"soy {nombre} y soy {puesto}")

informacion  ("juan","mecanico")  
informacion  ("nicolas", "ingeniero")  
informacion  ("esteban", "programador")  