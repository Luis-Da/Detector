def app():#los lenguajes de progracion pueden crear o leer archivos
    #crear archivo
    archivo= open("archivo.txt", "w")# open es una funcion de python para abrir archivos, el parametro 1 es el nombre del archivo, y el segundo parametro
    # es el modo o los permisos  w->permiso o modo de escritura y si no existe lo creara 



    #generar numeros en archivos
    for i in range (0,20):
        archivo.write("esta es la linea" + str(i) + "\r\n" )

        #cerrar el archivo
        archivo.close




app()