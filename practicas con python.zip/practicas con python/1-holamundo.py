tus_zonas= "erronenas"
comi= "barquillos"
print(comi)
print(tus_zonas)