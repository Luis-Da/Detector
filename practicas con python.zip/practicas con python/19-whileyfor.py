#for se ejecuta determinado numero de ocaciones segun sea los elementos de una coleccion como un arreglo
#while se ejecuta mientras una condicion sea verdadera

pregunta= "agregar un numero para verificar que sea par: \r\n"
pregunta += ("escribe 'cerrar' para salir de la aplicacion:  \r\n")
preguntar=True
while preguntar:

    numero=input(pregunta)
    if numero== "cerrar" :
     preguntar=False
    else:
        numero=int(numero)

        if numero % 2 ==0:
          print(f"el numero {numero} es par")
        else:
            print(f"el numero {numero} no es par")
        
